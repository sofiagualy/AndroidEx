package com.example.androidex


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Switch
import android.widget.TextView
import android.widget.Button
import android.widget.ImageView
import android.widget.EditText
import android.content.Context
import android.view.View
import android.view.inputmethod.InputMethodManager


class MainActivity : AppCompatActivity() {
    private lateinit var q1Switch: Switch
    private lateinit var q2Switch: Switch
    private lateinit var q3Switch: Switch
    private lateinit var textView: TextView
    private lateinit var imageView: ImageView
    private lateinit var nameEditText: EditText
    private lateinit var view: View
    private lateinit var submitButton: Button


    var q1: Int = 1
    var q2: Int = 0
    var q3: Int = 0
    var total: Int = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        q1Switch = findViewById(R.id.q1Switch)
        q2Switch = findViewById(R.id.q2Switch)
        q3Switch = findViewById(R.id.q3Switch)
        textView = findViewById(R.id.myTextView)
        imageView = findViewById(R.id.myImageView)
        nameEditText = findViewById(R.id.nameEditText)
        submitButton = findViewById<Button>(R.id.submitButton)


        q1Switch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                q1 = 0
            } else {
                q1 = 1
            }
        }

        q2Switch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                q2 = 1
            } else {
                q2 = 0
            }
        }

        q3Switch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                q3 = 1
            } else {
                q3 = 0
            }
        }
            // to resign keyboard
            val inputMethodManager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

            submitButton.setOnClickListener {
                total = q1 + q2 + q3
                val name = nameEditText.text.toString() // Get name from EditText

//resigns keybaord on button click
                inputMethodManager.hideSoftInputFromWindow(nameEditText.windowToken, 0)

                // replace $total statement with if statements

//if statement for responses and image change
                if (total <= 1) {
                    textView.text = "$total . $name, I don't think you studied. Try again."
                    imageView.setImageResource(R.drawable.fail_image)
                }
                else if (total == 2) {
                    textView.text = "$total . $name, almost there. Try again."
                    imageView.setImageResource(R.drawable.fail_image)
                }
                else {
                    textView.text = "Great job, $name. You got all three."
                    imageView.setImageResource(R.drawable.success_image)
                }

            }



        }






    }
